# SYNC/in crowd

A Pen created on CodePen.io. Original URL: [https://codepen.io/pharaohleap/pen/qBqOoBy](https://codepen.io/pharaohleap/pen/qBqOoBy).

